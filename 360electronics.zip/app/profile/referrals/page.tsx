import Referrals from '@/components/Profile/Refferals';
import ProfileLayout from '@/components/Layouts/ProfileLayout';

export default function ReferralsPage() {

  return (
    <ProfileLayout>

      <Referrals />
    </ProfileLayout>
  );
}