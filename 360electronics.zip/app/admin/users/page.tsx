"use client"

import { UsersTable } from "@/components/Admin/UserTable"

export default function UsersPage() {
  return (
    <div className="container mx-auto py-6">
        <UsersTable />
    </div>
  )
}
