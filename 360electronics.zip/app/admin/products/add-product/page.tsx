import AddProductPage from "@/components/Admin/Product/AddProduct";

export default function page() {
    return <AddProductPage/>;
  }
  