import { ProductsTable } from "@/components/Admin/Product/ProductTable";

export default function page() {
  return <ProductsTable />;
}
